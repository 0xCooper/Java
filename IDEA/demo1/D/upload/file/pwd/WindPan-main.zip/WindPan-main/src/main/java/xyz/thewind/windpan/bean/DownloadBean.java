package xyz.thewind.windpan.bean;

public class DownloadBean extends LocalFileBean{

}
